
  # Hospital Website with Doctors

  This is a code bundle for Hospital Website with Doctors. The original project is available at https://www.figma.com/design/9HroHpFf50xn8PAOfsMDjl/Hospital-Website-with-Doctors.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  